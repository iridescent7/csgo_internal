#define DETOURS_X86_OFFLINE_LIBRARY
#include "disasm.cpp"
