#pragma once
//#include "misc\translator.h"
