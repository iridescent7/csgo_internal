#include "colorpicker.h"

void Colorpicker::Scale()
{
	width  = DYN_X(200);
	height = DYN_Y(24);
}

void Colorpicker::Paint()
{
	
}

bool Colorpicker::Update(UINT msg, WPARAM wParam, LPARAM lParam)
{
	return false;
}