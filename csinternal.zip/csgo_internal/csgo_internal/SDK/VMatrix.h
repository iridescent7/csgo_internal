#pragma once

typedef float VMatrix[4][4];
typedef float matrix3x4_t[3][4];
